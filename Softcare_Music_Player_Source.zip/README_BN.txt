SOFTCARE MUSIC PLAYER — Android Project

প্রজেক্টে Android Studio/Gradle দিয়ে Debug APK তৈরি করা যায়।

গুরুত্বপূর্ণ: GitHub-এ ZIP-টি সাধারণ ফাইল হিসেবে আপলোড করলে ZIP-এর ভেতরের .github/workflows/build.yml স্বয়ংক্রিয়ভাবে সক্রিয় হয় না। ZIP-only পদ্ধতিতে নিচের একবারের সেটআপ প্রয়োজন।

১) GitHub-এ একটি Public অথবা Private repository তৈরি করুন।
২) Add file → Create new file চাপুন। ফাইলের নাম দিন: .github/workflows/build-from-zip.yml
৩) নিচের YAML কোডটি ওই ফাইলে পেস্ট করে Commit করুন।
৪) এরপর Add file → Upload files দিয়ে Softcare_Music_Player_Source.zip ফাইলটি আপলোড করে Commit করুন।
৫) Actions ট্যাবে Build Softcare from uploaded ZIP রান হবে। সফল হলে Artifacts থেকে APK নামিয়ে নিন।

এই ZIP-এর ভেতরের সোর্স প্রজেক্টে AndroidManifest label Softcare Music Player করা হয়েছে।

সীমাবদ্ধতা ও পরীক্ষা: এই পরিবেশে Android SDK/Gradle ইনস্টল নেই, তাই এখানে APK কম্পাইল করে বাস্তব ফোনে প্লেব্যাক পরীক্ষা করা সম্ভব হয়নি। GitHub Actions-এ প্রথম বিল্ডের ফলাফলই কম্পাইল যাচাই করবে; APK ফোনে ইনস্টল করে গান, overlay bubble, permissions এবং prayer lock আলাদাভাবে পরীক্ষা করতে হবে।
