package com.example.bubbleplayer;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * আজানের সময় গণনা (ঢাকা, GMT+6)। ইন্টারনেট লাগে না।
 * পদ্ধতি: University of Islamic Sciences, Karachi (ফজর ১৮°, ইশা ১৮°), আসর হানাফি।
 * মসজিদের জামাতের সময়ের সাথে কয়েক মিনিট তফাত হতে পারে, তাই আগে/পরের সময় বদলানো যায়।
 */
public class AzanGuard {
    static final double LAT = 23.8103, LON = 90.4125;
    static final TimeZone TZ = TimeZone.getTimeZone("GMT+06:00");
    static final String[] NAMES = {"ফজর", "যোহর", "আসর", "মাগরিব", "ইশা"};

    static int before() { return PlayerCore.sp.getInt("azan_before", 5); }
    static int after() { return PlayerCore.sp.getInt("azan_after", 5); }
    static boolean enabled() { return PlayerCore.sp.getBoolean("azan_on", true); }

    static double rad(double d) { return d * Math.PI / 180; }
    static double deg(double r) { return r * 180 / Math.PI; }

    /** আজকের পাঁচ ওয়াক্তের সময় (মিলিসেকেন্ডে, ঢাকার দিনের হিসাবে)। */
    static long[] times(Calendar day) {
        Calendar c = (Calendar) day.clone();
        c.setTimeZone(TZ);
        int y = c.get(Calendar.YEAR), m = c.get(Calendar.MONTH) + 1, d = c.get(Calendar.DAY_OF_MONTH);
        // জুলিয়ান দিন (দুপুর UT)
        int a = (14 - m) / 12, yy = y + 4800 - a, mm = m + 12 * a - 3;
        double jd = d + (153 * mm + 2) / 5 + 365.0 * yy + yy / 4 - yy / 100 + yy / 400 - 32045 - 0.5 + 0.0;
        double n = jd - 2451545.0 + 0.5;
        double L = (280.460 + 0.9856474 * n) % 360;
        double g = rad((357.528 + 0.9856003 * n) % 360);
        double lam = rad(L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g));
        double eps = rad(23.439 - 0.0000004 * n);
        double decl = Math.asin(Math.sin(eps) * Math.sin(lam));
        double ra = Math.atan2(Math.cos(eps) * Math.sin(lam), Math.cos(lam));
        double eqt = (L / 15.0) - (deg(ra) / 15.0);
        eqt = ((eqt + 12) % 24 + 24) % 24 - 12;
        double noon = 12 + 6 - LON / 15.0 - eqt; // ঢাকার স্থানীয় ঘড়িতে দুপুর (UTC+6)

        double fajr = noon - hourAngle(18, decl);
        double dhuhr = noon + 0.0333; // সূর্য ঢলার পর ২ মিনিট
        double asr = noon + asrAngle(2, decl);
        double maghrib = noon + hourAngle(0.833, decl) + 0.0167; // ১ মিনিট সতর্কতা
        double isha = noon + hourAngle(18, decl) + 0.0167; // ১ মিনিট সতর্কতা

        double[] hrs = {fajr, dhuhr, asr, maghrib, isha};
        long[] out = new long[5];
        Calendar base = Calendar.getInstance(TZ);
        base.setTimeInMillis(c.getTimeInMillis());
        base.set(Calendar.HOUR_OF_DAY, 0); base.set(Calendar.MINUTE, 0); base.set(Calendar.SECOND, 0); base.set(Calendar.MILLISECOND, 0);
        for (int i = 0; i < 5; i++) out[i] = base.getTimeInMillis() + (long) (hrs[i] * 3600000L);
        return out;
    }

    static double hourAngle(double angle, double decl) {
        double x = (-Math.sin(rad(angle)) - Math.sin(rad(LAT)) * Math.sin(decl)) / (Math.cos(rad(LAT)) * Math.cos(decl));
        return deg(Math.acos(Math.max(-1, Math.min(1, x)))) / 15.0;
    }

    static double asrAngle(double shadow, double decl) {
        double a = Math.atan(1.0 / (shadow + Math.tan(Math.abs(rad(LAT) - decl))));
        double x = (Math.sin(a) - Math.sin(rad(LAT)) * Math.sin(decl)) / (Math.cos(rad(LAT)) * Math.cos(decl));
        return deg(Math.acos(Math.max(-1, Math.min(1, x)))) / 15.0;
    }

    /** এখন আজানের নিষিদ্ধ সময়ে আছি কিনা। থাকলে ওয়াক্তের নাম, নইলে null। */
    static String blockedNow() {
        if (!enabled()) return null;
        long now = System.currentTimeMillis();
        Calendar c = Calendar.getInstance(TZ);
        c.setTimeInMillis(now);
        long[] t = times(c);
        for (int i = 0; i < 5; i++) {
            if (now >= t[i] - before() * 60000L && now <= t[i] + after() * 60000L) return NAMES[i];
        }
        return null;
    }

    /** কতক্ষণ পর নিষেধাজ্ঞা শেষ (মিনিট), বার্তার জন্য। */
    static int minutesLeft() {
        long now = System.currentTimeMillis();
        Calendar c = Calendar.getInstance(TZ); c.setTimeInMillis(now);
        long[] t = times(c);
        for (int i = 0; i < 5; i++) {
            long end = t[i] + after() * 60000L;
            if (now >= t[i] - before() * 60000L && now <= end) return (int) Math.max(1, (end - now) / 60000L + 1);
        }
        return 0;
    }
}
