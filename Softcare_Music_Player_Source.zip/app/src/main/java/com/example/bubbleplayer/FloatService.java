package com.example.bubbleplayer;

import android.animation.ValueAnimator;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;

public class FloatService extends Service {
    static final String ACT_TOGGLE = "bp.toggle", ACT_NEXT = "bp.next", ACT_PREV = "bp.prev", ACT_STOP = "bp.stop";
    WindowManager wm; FrameLayout root; WindowManager.LayoutParams lp;
    CoverView small, big; LinearLayout panel; TextView title, artist, cur, total, azan; SeekBar seek;
    IconButton prev, play, next, shuf, rep, close; boolean expanded;
    GradientDrawable panelBg;
    float dx, dy; int ox, oy; boolean moved;
    Runnable ui = this::refresh;
    boolean dragging;
    int lastNotifState = -1;

    @Override public IBinder onBind(Intent i) { return null; }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override public int onStartCommand(Intent i, int f, int id) {
        PlayerCore.init(this);
        String a = i != null ? i.getAction() : null;
        if (ACT_TOGGLE.equals(a)) PlayerCore.toggle();
        else if (ACT_NEXT.equals(a)) PlayerCore.step(1);
        else if (ACT_PREV.equals(a)) PlayerCore.step(-1);
        else if (ACT_STOP.equals(a)) { PlayerCore.pause(); stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        pushNotification(true);
        if (root == null && Settings.canDrawOverlays(this)) setup();
        return START_STICKY;
    }

    PendingIntent act(String a, int code) {
        Intent in = new Intent(this, FloatService.class).setAction(a);
        return PendingIntent.getService(this, code, in, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    void pushNotification(boolean first) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("bp", "Bubble Player", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        boolean pl = PlayerCore.playing();
        Notification.Builder b = new Notification.Builder(this, "bp")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(PlayerCore.title()).setContentText(PlayerCore.artist())
            .setContentIntent(pi).setOnlyAlertOnce(true).setColor(PlayerCore.accent())
            .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_previous), "আগের", act(ACT_PREV, 1)).build())
            .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, pl ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play), pl ? "পজ" : "প্লে", act(ACT_TOGGLE, 2)).build())
            .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_next), "পরের", act(ACT_NEXT, 3)).build())
            .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "বন্ধ", act(ACT_STOP, 4)).build());
        if (PlayerCore.cover != null) b.setLargeIcon(PlayerCore.cover);
        Notification n = b.build();
        if (first) {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(1, n);
        } else nm.notify(1, n);
    }

    GradientDrawable pill(int color, int radius, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius)); g.setStroke(dp(1), strokeColor);
        return g;
    }

    void setup() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        small = new CoverView(this);
        small.setLayoutParams(new FrameLayout.LayoutParams(dp(64), dp(64)));

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(18), dp(16), dp(18), dp(16));
        panelBg = pill(0xE6101820, 32, 0x44FFFFFF);
        panel.setBackground(panelBg);
        panel.setLayoutParams(new FrameLayout.LayoutParams(dp(280), -2));
        panel.setVisibility(View.GONE);

        // ওপরের সারি: বন্ধ বোতাম
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.END);
        close = new IconButton(this, 7).small();
        close.setOnClickListener(v -> expand(false));
        top.addView(close, new LinearLayout.LayoutParams(dp(30), dp(30)));
        panel.addView(top, new LinearLayout.LayoutParams(-1, -2));

        big = new CoverView(this);
        panel.addView(big, new LinearLayout.LayoutParams(dp(130), dp(130)));
        title = new TextView(this);
        title.setTextColor(Color.WHITE); title.setTextSize(17); title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true); title.setEllipsize(TextUtils.TruncateAt.MARQUEE); title.setSelected(true);
        title.setGravity(Gravity.CENTER); title.setPadding(0, dp(8), 0, 0);
        panel.addView(title, new LinearLayout.LayoutParams(-1, -2));
        artist = new TextView(this);
        artist.setTextColor(0xAAFFFFFF); artist.setTextSize(12); artist.setSingleLine(true);
        artist.setEllipsize(TextUtils.TruncateAt.END); artist.setGravity(Gravity.CENTER);
        panel.addView(artist, new LinearLayout.LayoutParams(-1, -2));

        azan = new TextView(this);
        azan.setTextColor(Color.WHITE); azan.setTextSize(22); azan.setTypeface(Typeface.DEFAULT_BOLD);
        azan.setGravity(Gravity.CENTER); azan.setPadding(0, dp(8), 0, dp(8));
        azan.setVisibility(View.GONE);
        panel.addView(azan, new LinearLayout.LayoutParams(-1, -2));
        seek = new SeekBar(this);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { if (u) PlayerCore.seek(p); }
            public void onStartTrackingTouch(SeekBar s) { dragging = true; }
            public void onStopTrackingTouch(SeekBar s) { dragging = false; }
        });
        panel.addView(seek, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout times = new LinearLayout(this);
        cur = new TextView(this); total = new TextView(this);
        cur.setTextColor(0x99FFFFFF); total.setTextColor(0x99FFFFFF); cur.setTextSize(11); total.setTextSize(11);
        times.addView(cur, new LinearLayout.LayoutParams(0, -2, 1));
        total.setGravity(Gravity.END);
        times.addView(total, new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(times, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        shuf = new IconButton(this, 4).small(); rep = new IconButton(this, 5).small();
        prev = new IconButton(this, 0); play = new IconButton(this, 1); next = new IconButton(this, 2);
        shuf.setOnClickListener(v -> PlayerCore.toggleShuffle());
        rep.setOnClickListener(v -> PlayerCore.cycleRepeat());
        prev.setOnClickListener(v -> PlayerCore.step(-1));
        play.setOnClickListener(v -> PlayerCore.toggle());
        next.setOnClickListener(v -> PlayerCore.step(1));
        row.addView(shuf, new LinearLayout.LayoutParams(dp(34), dp(34)));
        row.addView(prev, new LinearLayout.LayoutParams(dp(46), dp(46)));
        row.addView(play, new LinearLayout.LayoutParams(dp(64), dp(64)));
        row.addView(next, new LinearLayout.LayoutParams(dp(46), dp(46)));
        row.addView(rep, new LinearLayout.LayoutParams(dp(34), dp(34)));
        panel.addView(row, new LinearLayout.LayoutParams(-1, -2));

        root = new FrameLayout(this);
        root.addView(small); root.addView(panel);
        lp = new WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START; lp.x = 0; lp.y = 300;
        root.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (expanded) return false;
                    dx = e.getRawX(); dy = e.getRawY(); ox = lp.x; oy = lp.y; moved = false; return true;
                case MotionEvent.ACTION_MOVE:
                    if (expanded) return false;
                    if (Math.abs(e.getRawX() - dx) > 12 || Math.abs(e.getRawY() - dy) > 12) moved = true;
                    if (moved) { lp.x = ox + (int) (e.getRawX() - dx); lp.y = oy + (int) (e.getRawY() - dy); wm.updateViewLayout(root, lp); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (expanded) return false;
                    if (!moved) expand(true); else snap();
                    return true;
                case MotionEvent.ACTION_OUTSIDE:
                    if (expanded) expand(false); return true;
            }
            return false;
        });
        wm.addView(root, lp);
        PlayerCore.ls.add(ui);
        refresh();
    }

    /** বাবল ছেড়ে দিলে কাছের কিনারায় নরম অ্যানিমেশনে আটকে যায়। */
    void snap() {
        DisplayMetrics m = getResources().getDisplayMetrics();
        int target = (lp.x + dp(32) < m.widthPixels / 2) ? -dp(10) : m.widthPixels - dp(64) + dp(10);
        ValueAnimator va = ValueAnimator.ofInt(lp.x, target);
        va.setDuration(220);
        va.addUpdateListener(a -> { if (root != null) { lp.x = (int) a.getAnimatedValue(); wm.updateViewLayout(root, lp); } });
        va.start();
    }

    void expand(boolean b) {
        expanded = b;
        small.setVisibility(b ? View.GONE : View.VISIBLE);
        panel.setVisibility(b ? View.VISIBLE : View.GONE);
        if (b) {
            DisplayMetrics m = getResources().getDisplayMetrics();
            lp.x = Math.max(dp(8), Math.min(lp.x, m.widthPixels - dp(288)));
            panel.setAlpha(0f); panel.setScaleX(0.85f); panel.setScaleY(0.85f);
            panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start();
        }
        lp.flags = b ? WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                     : WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        wm.updateViewLayout(root, lp);
    }

    void refresh() {
        if (root == null) return;
        boolean pl = PlayerCore.playing();
        int a = PlayerCore.accent();
        small.set(PlayerCore.cover, pl, a);
        big.set(PlayerCore.cover, pl, a);
        title.setText(PlayerCore.title());
        artist.setText(PlayerCore.artist());
        panelBg.setColor(0xEE000000 | (PlayerCore.mix(a, 0xFF000000, 0.88f) & 0x00FFFFFF));
        panelBg.setStroke(dp(1), (a & 0x00FFFFFF) | 0x66000000);
        prev.set(pl, a); next.set(pl, a); play.set(pl, a);
        shuf.set(pl, a); shuf.setActive(PlayerCore.shuffle, false);
        rep.set(pl, a); rep.setActive(PlayerCore.repeat != PlayerCore.REPEAT_OFF, PlayerCore.repeat == PlayerCore.REPEAT_ONE);
        close.set(pl, a);
        int d = PlayerCore.dur();
        if (!dragging && d > 0) { seek.setMax(d); seek.setProgress(PlayerCore.pos()); }
        cur.setText(PlayerCore.fmt(PlayerCore.pos())); total.setText(PlayerCore.fmt(d));
        String aw = AzanGuard.blockedNow();
        if (aw != null) { azan.setText("🕌 আজান টাইম\n" + aw + " • " + AzanGuard.minutesLeft() + " মিনিট"); azan.setVisibility(View.VISIBLE); }
        else azan.setVisibility(View.GONE);
        int st = (pl ? 1 : 0) + PlayerCore.idx * 2;
        if (st != lastNotifState) { lastNotifState = st; pushNotification(false); }
    }

    @Override public void onDestroy() {
        PlayerCore.ls.remove(ui);
        if (root != null) { try { wm.removeView(root); } catch (Exception ignored) {} root = null; }
        super.onDestroy();
    }
}
